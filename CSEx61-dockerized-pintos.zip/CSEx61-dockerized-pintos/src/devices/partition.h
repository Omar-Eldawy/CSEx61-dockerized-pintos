#ifndef DEVICES_PARTITION_H
#define DEVICES_PARTITION_H

struct block;

void partition_scan (struct block *);

#endif /* devices/partition.h */
